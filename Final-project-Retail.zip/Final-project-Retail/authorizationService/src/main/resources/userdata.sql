INSERT INTO userdata (user_id,user_name,user_password) VALUES ('101','John','abc123');
INSERT INTO userdata (user_id,user_name,user_password) VALUES ('102','Divya','abc123');
INSERT INTO userdata (user_id,user_name,user_password) VALUES ('103','Rishab','abc123');
INSERT INTO userdata (user_id,user_name,user_password) VALUES ('104','Ram','abc123');
INSERT INTO userdata (user_id,user_name,user_password) VALUES ('105','Venkat','abc123');

