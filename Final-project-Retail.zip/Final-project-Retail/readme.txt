port numbers
1) product-service : 8083
2) proceedToBuy-service : 8084
3) vendor-service : 8085
4) retailshop-service : 8086
5) eureka client : 8761 - http://localhost:8761/
6) auth-service : 8082

Our ui - retailshop-service : 8086
localhost:8086/login - Login Page
localhost:8086/product - Products List
localhost:8086/cart - Customer Cart
localhost:8086/error - If any error occures